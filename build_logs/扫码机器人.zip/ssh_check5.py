import paramiko
import time
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
max_retries = 3
for i in range(max_retries):
    try:
        ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30)
        break
    except Exception as e:
        print(f'Retry {i+1}: {e}')
        time.sleep(3)
else:
    print('Failed to connect')
    exit(1)

cmds = [
    'cd /www/server/panel && python3 -c "import sqlite3; db=sqlite3.connect(\"data/default.db\"); c=db.cursor(); c.execute(\"SELECT mysql_root FROM config LIMIT 1\"); print(c.fetchall())" 2>&1',
    'cat /www/server/nginx/conf/nginx.conf 2>/dev/null | head -60',
    'ls /www/wwwroot/qr.wzdi.cn/ 2>/dev/null',
    'cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf 2>/dev/null',
]
for cmd in cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=15)
    out = stdout.read().decode('utf-8', errors='replace').strip()
    err = stderr.read().decode('utf-8', errors='replace').strip()
    print(f'CMD: {cmd}')
    if out: print(f'  OUT: {out}')
    if err: print(f'  ERR: {err}')
    print()
ssh.close()
