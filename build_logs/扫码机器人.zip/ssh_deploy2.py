import paramiko
import time
import os
import re

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting to SSH...')
for i in range(3):
    try:
        ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30, banner_timeout=60, auth_timeout=30)
        print(f'Connected on attempt {i+1}!')
        break
    except Exception as e:
        print(f'Attempt {i+1} failed: {e}')
        time.sleep(15)
else:
    print('All SSH attempts failed - will try web deployment')
    exit(1)

# Step 1: Get MySQL root password
print('\n=== Getting MySQL root password ===')
stdin, stdout, stderr = ssh.exec_command(
    'cd /www/server/panel && python3 -c "import sqlite3;db=sqlite3.connect(\'data/default.db\');c=db.cursor();c.execute(\'SELECT mysql_root FROM config\');r=c.fetchone();print(r[0] if r else None)"',
    timeout=15
)
mysql_pwd = stdout.read().decode('utf-8', errors='replace').strip()
err = stderr.read().decode('utf-8', errors='replace').strip()
if err: print(f'Error: {err}')
print(f'MySQL root password: {"found" if mysql_pwd and mysql_pwd != "None" else "not found"}')

if not mysql_pwd or mysql_pwd == "None":
    # Try to reset MySQL root password
    print('Resetting MySQL root password...')
    stdin, stdout, stderr = ssh.exec_command(
        'cd /www/server/panel && python3 tools.py mysql_root 2>&1 || /etc/init.d/mysqld stop 2>&1',
        timeout=15
    )
    print(stdout.read().decode('utf-8', errors='replace').strip())
    # Try bt command
    stdin, stdout, stderr = ssh.exec_command('echo "ScanRobot@2026!" | bt 5 2>&1', timeout=15)
    print(stdout.read().decode('utf-8', errors='replace').strip())
    mysql_pwd = "ScanRobot@2026!"

# Step 2: Test MySQL connection
print('\n=== Testing MySQL ===')
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" -e "SELECT 1;" 2>&1',
    timeout=10
)
mysql_test = stdout.read().decode('utf-8', errors='replace').strip()
print(f'MySQL test: {"OK" if "1" in mysql_test and "ERROR" not in mysql_test else mysql_test}')

if "ERROR" in mysql_test or "denied" in mysql_test.lower():
    print('MySQL access failed. Trying alternative...')
    # Try without password
    stdin, stdout, stderr = ssh.exec_command(
        'mysql -u root -e "SELECT 1;" 2>&1',
        timeout=10
    )
    alt_test = stdout.read().decode('utf-8', errors='replace').strip()
    print(f'Without password: {alt_test}')
    # Try with SSH password
    stdin, stdout, stderr = ssh.exec_command(
        'mysql -u root -p"1eZjerlED2NF" -e "SELECT 1;" 2>&1',
        timeout=10
    )
    alt_test2 = stdout.read().decode('utf-8', errors='replace').strip()
    print(f'With SSH password: {alt_test2}')

# Step 3: Create database and user
print('\n=== Creating database ===')
sql_cmds = [
    f'mysql -u root -p"{mysql_pwd}" -e "CREATE DATABASE IF NOT EXISTS scan_robot DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>&1',
    f'mysql -u root -p"{mysql_pwd}" -e "CREATE USER IF NOT EXISTS \'scan_robot\'@\'localhost\' IDENTIFIED BY \'ScanRobot@2026!\';" 2>&1',
    f'mysql -u root -p"{mysql_pwd}" -e "GRANT ALL PRIVILEGES ON scan_robot.* TO \'scan_robot\'@\'localhost\'; FLUSH PRIVILEGES;" 2>&1',
]
for cmd in sql_cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
    out = stdout.read().decode('utf-8', errors='replace').strip()
    if out and 'Warning' not in out: print(f'  {out}')

# Step 4: Upload PHP files
print('\n=== Uploading PHP files ===')
sftp = ssh.open_sftp()

api_dir = '/www/wwwroot/qr.wzdi.cn/api'
stdin, stdout, stderr = ssh.exec_command(f'mkdir -p {api_dir}', timeout=10)
stdout.read()

local_api_dir = r'e:\工作路径\6a80b60ed76c53d761ba65ee\scan-robot-android\php-api'
php_files = ['config.php', 'init.php', 'register.php', 'login.php', 'forgot_password.php', 'reset_password.php']

for f in php_files:
    local_path = os.path.join(local_api_dir, f)
    remote_path = f'{api_dir}/{f}'
    try:
        sftp.put(local_path, remote_path)
        print(f'  Uploaded: {f}')
    except Exception as e:
        print(f'  Failed {f}: {e}')

sftp.close()

# Step 5: Set permissions
print('\n=== Setting permissions ===')
stdin, stdout, stderr = ssh.exec_command(f'chown -R www:www {api_dir} && chmod -R 755 {api_dir}', timeout=10)
stdout.read()
print('Permissions set')

# Step 6: Initialize database
print('\n=== Initializing database tables ===')
stdin, stdout, stderr = ssh.exec_command(
    f'curl -s http://127.0.0.1/api/init.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
init_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Init result: {init_result}')

# Step 7: Test API
print('\n=== Testing API ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s -X POST http://127.0.0.1/api/login.php -H "Host: qr.wzdi.cn" -H "Content-Type: application/json" -d \'{"username":"test","password":"test"}\'',
    timeout=15
)
test_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Login test: {test_result}')

# Step 8: Check nginx config
print('\n=== Nginx config ===')
stdin, stdout, stderr = ssh.exec_command(
    'cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf 2>/dev/null | head -30',
    timeout=10
)
nginx_conf = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Nginx:\n{nginx_conf}')

ssh.close()
print('\n=== Deployment complete! ===')
