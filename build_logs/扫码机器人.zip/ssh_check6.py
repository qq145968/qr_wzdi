import paramiko
import time
import socket

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# Try connecting with longer timeout
for i in range(3):
    try:
        print(f'Attempt {i+1}...')
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        result = sock.connect_ex(('156.225.17.203', 22))
        print(f'  Port 22 connect result: {result}')
        sock.close()
        if result == 0:
            ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30, banner_timeout=30)
            print('  Connected!')
            break
    except Exception as e:
        print(f'  Error: {e}')
        time.sleep(5)
else:
    print('All attempts failed')
    exit(1)

# Now get MySQL root password - use bt command
cmds = [
    'echo "1eZjerlED2NF" | bt 5 2>&1',
    'cat /www/server/panel/data/default.pl 2>/dev/null',
    'cat /www/server/panel/data/domain.conf 2>/dev/null',
    'cat /www/server/panel/data/admin_path.pl 2>/dev/null',
    'ls /www/wwwroot/qr.wzdi.cn/ 2>/dev/null',
    'cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf 2>/dev/null | head -30',
    'cat /www/server/panel/vhost/nginx/cc.wzdi.cn.conf 2>/dev/null | head -30',
]
for cmd in cmds:
    try:
        stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
        out = stdout.read().decode('utf-8', errors='replace').strip()
        err = stderr.read().decode('utf-8', errors='replace').strip()
        print(f'CMD: {cmd}')
        if out: print(f'  OUT: {out}')
        if err: print(f'  ERR: {err}')
        print()
    except Exception as e:
        print(f'CMD: {cmd} -> ERROR: {e}')
        print()
ssh.close()
print('Done')
