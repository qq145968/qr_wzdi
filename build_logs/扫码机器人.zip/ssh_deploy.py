import paramiko
import time
import os

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting to SSH...')
for i in range(5):
    try:
        ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30, banner_timeout=30)
        print(f'Connected on attempt {i+1}!')
        break
    except Exception as e:
        print(f'Attempt {i+1} failed: {e}')
        time.sleep(10)
else:
    print('All SSH attempts failed')
    exit(1)

# Step 1: Get MySQL root password from BT panel
print('\n=== Getting MySQL root password ===')
stdin, stdout, stderr = ssh.exec_command('cd /www/server/panel && python3 -c "import sqlite3; db=sqlite3.connect(\'data/default.db\'); c=db.cursor(); c.execute(\'SELECT mysql_root FROM config LIMIT 1\'); print(c.fetchall())"', timeout=15)
out = stdout.read().decode('utf-8', errors='replace').strip()
err = stderr.read().decode('utf-8', errors='replace').strip()
print(f'MySQL root: {out}')
if err: print(f'Err: {err}')

# Step 2: Check if we can access MySQL
print('\n=== Testing MySQL access ===')
# Try common BT panel MySQL root passwords
stdin, stdout, stderr = ssh.exec_command('cat /www/server/panel/data/default.pl 2>/dev/null', timeout=10)
panel_pwd = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Panel password file: {panel_pwd}')

# Try to get MySQL root password from BT panel database
stdin, stdout, stderr = ssh.exec_command('cd /www/server/panel && python3 -c "import sqlite3;db=sqlite3.connect(\'data/default.db\');c=db.cursor();c.execute(\'SELECT mysql_root FROM config\');print(c.fetchone())"', timeout=10)
mysql_root_out = stdout.read().decode('utf-8', errors='replace').strip()
mysql_root_err = stderr.read().decode('utf-8', errors='replace').strip()
print(f'MySQL root from DB: {mysql_root_out}')
if mysql_root_err: print(f'Err: {mysql_root_err}')

# Extract password from the output
import re
mysql_pwd = None
if mysql_root_out:
    match = re.search(r"\('([^']*)'\)", mysql_root_out)
    if match:
        mysql_pwd = match.group(1)
        print(f'Extracted MySQL root password: {mysql_pwd}')

# Step 3: Create database and user
if mysql_pwd:
    print('\n=== Creating database ===')
    cmds = [
        f'mysql -u root -p"{mysql_pwd}" -e "CREATE DATABASE IF NOT EXISTS scan_robot DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>&1',
        f'mysql -u root -p"{mysql_pwd}" -e "CREATE USER IF NOT EXISTS \'scan_robot\'@\'localhost\' IDENTIFIED BY \'ScanRobot@2026!\';" 2>&1',
        f'mysql -u root -p"{mysql_pwd}" -e "GRANT ALL PRIVILEGES ON scan_robot.* TO \'scan_robot\'@\'localhost\'; FLUSH PRIVILEGES;" 2>&1',
    ]
    for cmd in cmds:
        stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
        out = stdout.read().decode('utf-8', errors='replace').strip()
        if out: print(f'  {out}')

# Step 4: Create API directory and upload files
print('\n=== Uploading PHP API files ===')
sftp = ssh.open_sftp()

api_dir = '/www/wwwroot/qr.wzdi.cn/api'
try:
    stdin, stdout, stderr = ssh.exec_command(f'mkdir -p {api_dir}', timeout=10)
    stdout.read()
except: pass

local_api_dir = r'e:\工作路径\6a80b60ed76c53d761ba65ee\scan-robot-android\php-api'
php_files = ['config.php', 'init.php', 'register.php', 'login.php', 'forgot_password.php', 'reset_password.php']

for f in php_files:
    local_path = os.path.join(local_api_dir, f)
    remote_path = f'{api_dir}/{f}'
    try:
        sftp.put(local_path, remote_path)
        print(f'  Uploaded: {f}')
    except Exception as e:
        print(f'  Failed {f}: {e}')

sftp.close()

# Step 5: Initialize database tables
print('\n=== Initializing database ===')
stdin, stdout, stderr = ssh.exec_command(f'curl -s http://127.0.0.1/api/init.php', timeout=15)
out = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Init result: {out}')

# Step 6: Check nginx config for qr.wzdi.cn
print('\n=== Checking nginx config ===')
stdin, stdout, stderr = ssh.exec_command('cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf 2>/dev/null | head -30', timeout=10)
out = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Nginx config:\n{out}')

# Step 7: Set permissions
print('\n=== Setting permissions ===')
stdin, stdout, stderr = ssh.exec_command(f'chown -R www:www {api_dir} && chmod -R 755 {api_dir}', timeout=10)
stdout.read()
print('Permissions set')

ssh.close()
print('\n=== Done! ===')
