import paramiko
import time

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting...')
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30)
print('Connected!')

DB_USER = 'qr_wzdi_cn'
DB_PASS = 'nFhKHWxriPK257hh'
DB_NAME = 'qr_wzdi_cn'

# Check existing table structures
print('\n=== app_messages table structure ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "DESCRIBE app_messages;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

print('\n=== app_versions table structure ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "DESCRIBE app_versions;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

print('\n=== app_settings table structure ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "DESCRIBE app_settings;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

print('\n=== app_messages data ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT * FROM app_messages;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

print('\n=== app_versions data ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT * FROM app_versions;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

print('\n=== All tables ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SHOW TABLES;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip())

ssh.close()
print('\nDone!')
