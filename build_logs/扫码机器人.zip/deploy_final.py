import paramiko
import time

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting...')
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30)
print('Connected!')

DB_USER = 'qr_wzdi_cn'
DB_PASS = 'nFhKHWxriPK257hh'
DB_NAME = 'qr_wzdi_cn'

# Step 1: Upload fixed app_info.php
print('\n=== Uploading fixed app_info.php ===')
sftp = ssh.open_sftp()
local_file = r'e:\工作路径\6a80b60ed76c53d761ba65ee\scan-robot-android\php-api\app_info.php'
remote_file = '/www/wwwroot/qr.wzdi.cn/api/app_info.php'
sftp.put(local_file, remote_file)
print('Uploaded!')
sftp.close()

stdin, stdout, stderr = ssh.exec_command(f'chown www:www {remote_file} && chmod 755 {remote_file}', timeout=10)
stdout.read()
print('Permissions set')

# Step 2: Update announcement
print('\n=== Updating announcement ===')
cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "UPDATE app_settings SET setting_value = '欢迎使用扫码机器人 v1.5.0！新增消息通知、版本更新检测功能。让手机变成扫码枪，高效便捷。' WHERE setting_key = 'announcement';" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip() or 'OK')

# Step 3: Insert test messages with correct column names
print('\n=== Inserting messages ===')
cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_messages (title, content, target_type, message_type, send_type, status, sent_at) VALUES ('欢迎使用扫码机器人', '感谢您使用扫码机器人 v1.5.0！新增功能：1.消息通知系统 2.版本自动更新检测 3.滚动公告栏 如有问题请及时反馈。', 'all', 'system', 'both', 'sent', NOW());" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip() or 'OK')

cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_messages (title, content, target_type, message_type, send_type, status, sent_at) VALUES ('系统维护通知', '系统将于今晚23:00-23:30进行例行维护，届时可能短暂无法访问，请提前做好准备。', 'all', 'system', 'both', 'sent', NOW());" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip() or 'OK')

# Step 4: Insert a version record (higher than current 160)
print('\n=== Inserting version ===')
cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_versions (version_code, version_name, platform, download_url, update_content, force_update, is_release, file_size) VALUES (7, '1.5.0', 'all', 'https://github.com/qq145968/qr_wzdi/releases', 'v1.5.0更新：修复闪退、消息通知、版本更新检测、滚动公告栏', 0, 1, 0);" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(stdout.read().decode('utf-8', errors='replace').strip() or 'OK')

# Step 5: Verify
print('\n=== Verifying ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT id, title, message_type, status FROM app_messages ORDER BY id DESC LIMIT 5;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(f'Messages:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT version_code, version_name, is_release FROM app_versions ORDER BY version_code DESC LIMIT 5;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(f'Versions:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

# Step 6: Test API via HTTPS
print('\n=== Testing API ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s -k https://127.0.0.1/api/app_info.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
api_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'API: {api_result[:1200]}')

ssh.close()
print('\n=== Done! ===')
