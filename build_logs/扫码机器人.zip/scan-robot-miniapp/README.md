# 扫码机器人 - 微信小程序

让手机变成扫码枪，支持条形码/二维码连续扫描、批次管理、导出记录。

## 功能

- **扫码设置**：半屏连扫/全屏单扫、允许重复录入、自动保存照片、扫码类型、提示方式
- **真实扫码**：调用 `wx.scanCode` 使用摄像头识别条形码和二维码
- **批次管理**：按日期自动分组、查看历史记录、清除数据
- **详情操作**：单条复制、全部复制、导出 CSV、继续扫码、删除单条
- **本地存储**：所有设置和扫码记录通过 `wx.setStorageSync` 持久化保存

## 项目结构

```
scan-robot-miniapp/
├── app.js              # 全局逻辑：数据管理、扫码记录增删、设置存取
├── app.json            # 全局配置：页面路由、tabBar、权限
├── app.wxss            # 全局样式：CSS 变量、通用组件
├── project.config.json # 项目配置
├── sitemap.json        # 站点地图
├── assets/
│   └── tabbar/         # tabBar 图标 (81x81 PNG)
└── pages/
    ├── scan/           # 扫码设置页（tabBar 页）
    │   ├── scan.js     # 设置逻辑、调用 wx.scanCode
    │   ├── scan.wxml   # 设置列表 UI
    │   ├── scan.wxss   # 设置页样式
    │   └── scan.json
    ├── manage/         # 管理页（tabBar 页）
    │   ├── manage.js   # 批次列表、导出、清除
    │   ├── manage.wxml # 批次列表 UI
    │   ├── manage.wxss # 管理页样式
    │   └── manage.json
    └── detail/         # 扫码列表详情页
        ├── detail.js   # 记录列表、复制、导出、删除、继续扫码
        ├── detail.wxml # 记录列表 UI
        ├── detail.wxss # 详情页样式
        └── detail.json
```

## 使用方法

1. 打开微信开发者工具
2. 导入项目，选择 `scan-robot-miniapp` 目录
3. AppID 选择"测试号"或填入你自己的 AppID
4. 点击编译预览

## 核心设计

- **主色调**：#1A73E8（蓝色）
- **背景色**：#F5F6F8（浅灰）
- **卡片式布局**：圆角 + 细边框
- **iOS 风格 Toggle 开关**：带弹性动画
- **底部弹出 Picker**：用于选择扫码模式、类型、提示方式

## 权限说明

- `scope.camera`：扫码时自动请求摄像头权限
- 不需要位置权限（已从 requiredPrivateInfos 中移除）
