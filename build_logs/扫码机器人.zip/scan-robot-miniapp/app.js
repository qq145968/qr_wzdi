App({
  globalData: {
    // 扫码设置
    settings: {
      scanMode: 'half',        // 扫码模式: half(半屏连扫) / full(全屏单扫)
      allowDuplicate: true,    // 允许二维码重复录入
      autoSavePhoto: true,     // 自动保存扫码照片
      scanType: 'all',         // 扫码类型: all(条形码+二维码) / barcode / qrcode
      alertType: 'sound'       // 扫码提示音: vibrate(震动) / sound("滴"声) / none(无)
    },
    // 扫码批次数据
    batches: []
  },

  onLaunch: function () {
    // 从本地存储加载设置和批次数据
    this.loadData();
  },

  loadData: function () {
    var settings = wx.getStorageSync('settings');
    if (settings) {
      this.globalData.settings = Object.assign(this.globalData.settings, settings);
    }

    var batches = wx.getStorageSync('batches');
    if (batches) {
      this.globalData.batches = batches;
    }
  },

  saveData: function () {
    wx.setStorageSync('settings', this.globalData.settings);
    wx.setStorageSync('batches', this.globalData.batches);
  },

  saveSettings: function () {
    wx.setStorageSync('settings', this.globalData.settings);
  },

  // 添加扫码记录
  addScanRecord: function (code, type) {
    var now = new Date();
    var pad = function (n) { return n < 10 ? '0' + n : '' + n; };

    var dateStr = now.getFullYear() + '' + pad(now.getMonth() + 1) + pad(now.getDate()) +
                  pad(now.getHours()) + pad(now.getMinutes());
    var fullTimeStr = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) +
                      ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
    var timeStr = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());

    var batches = this.globalData.batches;
    var settings = this.globalData.settings;

    // 检查重复
    if (!settings.allowDuplicate) {
      for (var i = 0; i < batches.length; i++) {
        for (var j = 0; j < batches[i].items.length; j++) {
          if (batches[i].items[j].code === code) {
            return { success: false, reason: 'duplicate' };
          }
        }
      }
    }

    // 找今天的批次或创建新批次
    var batch = null;
    var todayPrefix = dateStr.substring(0, 8);
    for (var k = 0; k < batches.length; k++) {
      if (batches[k].id.startsWith(todayPrefix)) {
        batch = batches[k];
        break;
      }
    }

    if (!batch) {
      batch = {
        id: dateStr,
        name: dateStr + '扫描列表',
        time: fullTimeStr,
        count: 0,
        items: []
      };
      batches.unshift(batch);
    }

    batch.items.push({
      code: code,
      type: type,
      time: timeStr
    });
    batch.count = batch.items.length;
    batch.time = fullTimeStr;

    this.saveData();
    return { success: true, batch: batch };
  },

  // 清除所有批次
  clearAllBatches: function () {
    this.globalData.batches = [];
    this.saveData();
  },

  // 获取扫码类型映射
  getScanTypes: function () {
    switch (this.globalData.settings.scanType) {
      case 'barcode':
        return ['barCode'];
      case 'qrcode':
        return ['qrCode'];
      default:
        return ['barCode', 'qrCode', 'datamatrix', 'pdf417'];
    }
  },

  // 触发提示
  triggerAlert: function () {
    switch (this.globalData.settings.alertType) {
      case 'vibrate':
        wx.vibrateShort({ type: 'medium' });
        break;
      case 'sound':
        // 播放系统消息音
        break;
      case 'none':
      default:
        break;
    }
  }
});
