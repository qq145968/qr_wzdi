// pages/scanner/scanner.js
var jsQR = require('../../utils/jsQR.js')

const app = getApp()

Page({
  data: {
    scanList: [],
    flashOn: false,
    cameraReady: false,
    scanning: true,
    recentCodes: {}
  },

  onLoad: function () {
    this.setData({ scanList: [], recentCodes: {} })
    this.initCamera()
  },

  onUnload: function () {
    this.stopScan()
  },

  onHide: function () {
    this.stopScan()
  },

  // 播放提示音（每次创建新实例，确保连续触发都能响）
  playBeep: function () {
    var settings = app.globalData.settings
    if (settings.alertType === 'none') return

    if (settings.alertType === 'sound' || settings.alertType === undefined) {
      var audio = wx.createInnerAudioContext()
      audio.src = '/assets/beep.wav'
      audio.volume = 1.0
      audio.play()
      audio.onEnded(function () {
        audio.destroy()
      })
      audio.onError(function () {
        audio.destroy()
      })
    }

    if (settings.alertType === 'vibrate') {
      wx.vibrateShort({ type: 'medium' })
    } else if (settings.alertType === 'sound' || settings.alertType === undefined) {
      wx.vibrateShort({ type: 'light' })
    }
  },

  initCamera: function () {
    var that = this
    this.setData({ cameraReady: true })

    // 等待 camera 组件就绪后绑定帧监听
    setTimeout(function () {
      that.startFrameListener()
    }, 500)
  },

  startFrameListener: function () {
    var that = this
    this.cameraCtx = wx.createCameraContext()

    this.listener = this.cameraCtx.onCameraFrame(function (frame) {
      if (!that.data.scanning) return

      // jsQR 需要 Uint8ClampedArray 格式的 RGBA 数据
      var data = new Uint8ClampedArray(frame.data)
      var result = jsQR(data, frame.width, frame.height, {
        inversionAttempts: 'dontInvert'
      })

      if (result && result.data) {
        var code = result.data
        that.handleScanResult(code, 'qrcode')
      }
    })

    this.listener.start({
      success: function () {
        console.log('帧监听启动成功')
      },
      fail: function (err) {
        console.log('帧监听启动失败', err)
        // 降级到 wx.scanCode
        wx.showModal({
          title: '提示',
          content: '实时扫码启动失败，将使用系统扫码',
          showCancel: false,
          success: function () {
            that.fallbackScan()
          }
        })
      }
    })
  },

  stopScan: function () {
    this.setData({ scanning: false })
    if (this.listener) {
      this.listener.stop()
      this.listener = null
    }
  },

  // 降级方案：wx.scanCode
  fallbackScan: function () {
    var that = this
    this.setData({ scanning: true })

    wx.scanCode({
      onlyFromCamera: false,
      scanType: ['barCode', 'qrCode'],
      success: function (res) {
        var type = 'barcode'
        if (res.scanType === 'QR_CODE' || res.scanType === 'qrCode') {
          type = 'qrcode'
        }
        that.handleScanResult(res.result, type)

        // 连续扫
        setTimeout(function () {
          if (that.data.scanning) {
            that.fallbackScan()
          }
        }, 500)
      },
      fail: function () {
        // 用户取消
      }
    })
  },

  handleScanResult: function (code, type) {
    var settings = app.globalData.settings

    // 防抖：同一个码 2 秒内不重复添加
    var now = Date.now()
    if (this.data.recentCodes[code] && now - this.data.recentCodes[code] < 2000) {
      return
    }

    // 检查重复
    if (!settings.allowDuplicate) {
      var found = this.data.scanList.some(function (item) {
        return item.code === code
      })
      if (found) return
    }

    // 记录防抖
    var recentCodes = this.data.recentCodes
    recentCodes[code] = now
    this.setData({ recentCodes: recentCodes })

    // 播放提示音
    this.playBeep()

    // 生成时间
    var d = new Date()
    var pad = function (n) { return n < 10 ? '0' + n : '' + n }
    var timeStr = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds())

    // 添加到列表
    var list = this.data.scanList
    list.unshift({ code: code, type: type, time: timeStr })
    this.setData({ scanList: list })

    // 保存到全局
    app.addScanRecord(code, type)
  },

  // ===== 列表操作 =====
  previewCode: function (e) {
    var code = e.currentTarget.dataset.code
    wx.setClipboardData({
      data: code,
      success: function () {
        wx.showToast({ title: '已复制', icon: 'success', duration: 800 })
      }
    })
  },

  showItemMenu: function (e) {
    var index = e.currentTarget.dataset.index
    var item = this.data.scanList[index]
    var that = this

    wx.showActionSheet({
      itemList: ['复制此条', '删除此条'],
      success: function (res) {
        if (res.tapIndex === 0) {
          wx.setClipboardData({
            data: item.code,
            success: function () {
              wx.showToast({ title: '已复制', icon: 'success' })
            }
          })
        } else if (res.tapIndex === 1) {
          var list = that.data.scanList
          list.splice(index, 1)
          that.setData({ scanList: list })
          wx.showToast({ title: '已删除', icon: 'success' })
        }
      }
    })
  },

  copyAll: function () {
    if (this.data.scanList.length === 0) {
      wx.showToast({ title: '暂无内容', icon: 'none' })
      return
    }
    var text = this.data.scanList.map(function (i) { return i.code }).join('\n')
    wx.setClipboardData({
      data: text,
      success: function () {
        wx.showToast({ title: '已复制', icon: 'success' })
      }
    })
  },

  exportResult: function () {
    if (this.data.scanList.length === 0) {
      wx.showToast({ title: '暂无内容', icon: 'none' })
      return
    }
    var csv = '序号,编码,类型,时间\n'
    this.data.scanList.forEach(function (item, idx) {
      var t = item.type === 'qrcode' ? '二维码' : '条形码'
      csv += (idx + 1) + ',' + item.code + ',' + t + ',' + item.time + '\n'
    })
    var filePath = wx.env.USER_DATA_PATH + '/scan_' + Date.now() + '.csv'
    var fs = wx.getFileSystemManager()
    fs.writeFile({
      filePath: filePath,
      data: '\uFEFF' + csv,
      encoding: 'utf8',
      success: function () {
        wx.shareFileMessage({
          filePath: filePath,
          fail: function () {
            wx.showToast({ title: '已导出CSV', icon: 'success' })
          }
        })
      },
      fail: function () {
        wx.showToast({ title: '导出失败', icon: 'none' })
      }
    })
  },

  // ===== 摄像头控制 =====
  toggleFlash: function () {
    var newVal = !this.data.flashOn
    // 先停掉帧监听
    this.stopScan()
    // 关掉 camera 再开，强制重新读取 flash 属性
    this.setData({ cameraReady: false, flashOn: newVal })
    var that = this
    setTimeout(function () {
      that.setData({ cameraReady: true, scanning: true })
      // 重新启动帧监听
      setTimeout(function () {
        that.startFrameListener()
      }, 500)
      wx.showToast({
        title: newVal ? '闪光灯已开' : '闪光灯已关',
        icon: 'none',
        duration: 800
      })
    }, 200)
  },

  onCameraError: function () {
    wx.showToast({
      title: '摄像头启动失败',
      icon: 'none',
      duration: 2000
    })
    this.fallbackScan()
  },

  goBack: function () {
    wx.navigateBack()
  }
})
