// pages/detail/detail.js
const app = getApp()

Page({
  data: {
    batchId: '',
    batch: null,
    isEmpty: false
  },

  onLoad: function (options) {
    if (options.id) {
      this.setData({ batchId: options.id })
      this.loadBatch(options.id)
    }
  },

  loadBatch: function (id) {
    var batches = app.globalData.batches
    var batch = null

    for (var i = 0; i < batches.length; i++) {
      if (batches[i].id === id) {
        batch = batches[i]
        break
      }
    }

    if (batch) {
      wx.setNavigationBarTitle({ title: batch.name })
      this.setData({
        batch: batch,
        isEmpty: batch.items.length === 0
      })
    }
  },

  // 复制单条
  copyOne: function (e) {
    var code = e.currentTarget.dataset.code
    wx.setClipboardData({
      data: code,
      success: function () {
        wx.showToast({ title: '已复制', icon: 'success' })
      }
    })
  },

  // 复制全部
  copyAll: function () {
    if (!this.data.batch || this.data.batch.items.length === 0) {
      wx.showToast({ title: '暂无内容可复制', icon: 'none' })
      return
    }

    var text = this.data.batch.items.map(function (item) {
      return item.code
    }).join('\n')

    wx.setClipboardData({
      data: text,
      success: function () {
        wx.showToast({ title: '已复制全部', icon: 'success' })
      }
    })
  },

  // 导出当前批次
  exportBatch: function () {
    if (!this.data.batch || this.data.batch.items.length === 0) {
      wx.showToast({ title: '暂无内容可导出', icon: 'none' })
      return
    }

    var batch = this.data.batch
    var csv = '序号,编码,类型,时间\n'
    batch.items.forEach(function (item, idx) {
      var typeLabel = item.type === 'qrcode' ? '二维码' : '条形码'
      csv += (idx + 1) + ',' + item.code + ',' + typeLabel + ',' + item.time + '\n'
    })

    var filePath = wx.env.USER_DATA_PATH + '/batch_' + batch.id + '.csv'
    var fs = wx.getFileSystemManager()
    fs.writeFile({
      filePath: filePath,
      data: '\uFEFF' + csv,
      encoding: 'utf8',
      success: function () {
        wx.shareFileMessage({
          filePath: filePath,
          success: function () {},
          fail: function () {
            wx.showToast({ title: '已导出CSV', icon: 'success' })
          }
        })
      },
      fail: function () {
        wx.showToast({ title: '导出失败', icon: 'none' })
      }
    })
  },

  // 分享
  shareResult: function () {
    if (!this.data.batch || this.data.batch.items.length === 0) {
      wx.showToast({ title: '暂无可分享的内容', icon: 'none' })
      return
    }
    var text = this.data.batch.items.map(function (item) {
      return item.code
    }).join('\n')

    wx.setClipboardData({
      data: text,
      success: function () {
        wx.showToast({ title: '已复制，可粘贴分享', icon: 'none' })
      }
    })
  },

  // 单项操作菜单
  showItemMenu: function (e) {
    var index = e.currentTarget.dataset.index
    var item = this.data.batch.items[index]
    var that = this

    wx.showActionSheet({
      itemList: ['复制此条', '删除此条', '分享此条'],
      success: function (res) {
        if (res.tapIndex === 0) {
          wx.setClipboardData({
            data: item.code,
            success: function () {
              wx.showToast({ title: '已复制', icon: 'success' })
            }
          })
        } else if (res.tapIndex === 1) {
          var batch = that.data.batch
          batch.items.splice(index, 1)
          batch.count = batch.items.length
          app.saveData()
          that.setData({ batch: batch, isEmpty: batch.items.length === 0 })
          wx.showToast({ title: '已删除', icon: 'success' })
        } else if (res.tapIndex === 2) {
          wx.setClipboardData({
            data: item.code,
            success: function () {
              wx.showToast({ title: '已复制，可分享', icon: 'none' })
            }
          })
        }
      }
    })
  },

  // 继续扫码（向当前批次添加）
  continueScan: function () {
    var that = this
    var scanTypes = app.getScanTypes()

    wx.scanCode({
      onlyFromCamera: false,
      scanType: scanTypes,
      success: function (res) {
        var type = 'barcode'
        if (res.scanType === 'QR_CODE' || res.scanType === 'qrCode') {
          type = 'qrcode'
        }

        app.triggerAlert()

        var batch = that.data.batch
        var now = new Date()
        var pad = function (n) { return n < 10 ? '0' + n : '' + n }
        var timeStr = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds())

        // 检查重复
        if (!app.globalData.settings.allowDuplicate) {
          var found = false
          for (var i = 0; i < batch.items.length; i++) {
            if (batch.items[i].code === res.result) {
              found = true
              break
            }
          }
          if (found) {
            wx.showModal({
              title: '重复录入',
              content: '该码已存在',
              showCancel: false
            })
            return
          }
        }

        batch.items.push({ code: res.result, type: type, time: timeStr })
        batch.count = batch.items.length
        app.saveData()

        that.setData({ batch: batch, isEmpty: false })
        wx.showToast({ title: '已添加', icon: 'success' })
      }
    })
  }
})
