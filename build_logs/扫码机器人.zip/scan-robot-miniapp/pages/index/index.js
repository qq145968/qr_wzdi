// pages/index/index.js
const app = getApp()

Page({
  data: {
    activeTab: 'scan',
    settings: {},
    batches: [],
    scanModeText: '半屏连扫',
    scanTypeText: '条形码+二维码',
    alertTypeText: '"滴"声',
    showPicker: false,
    pickerTitle: '',
    pickerOptions: [],
    pickerType: '',
    pickerIndex: 0
  },

  onLoad: function () {
    this.loadSettings()
    this.loadBatches()
  },

  onShow: function () {
    this.loadSettings()
    this.loadBatches()
  },

  switchTab: function (e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab })
    if (this.data.activeTab === 'manage') {
      this.loadBatches()
    }
  },

  loadSettings: function () {
    var s = app.globalData.settings
    var modeMap = { half: '半屏连扫', full: '全屏单扫' }
    var typeMap = { all: '条形码+二维码', barcode: '仅条形码', qrcode: '仅二维码' }
    var alertMap = { vibrate: '震动', sound: '"滴"声', none: '无提示' }
    this.setData({
      settings: s,
      scanModeText: modeMap[s.scanMode] || '半屏连扫',
      scanTypeText: typeMap[s.scanType] || '条形码+二维码',
      alertTypeText: alertMap[s.alertType] || '"滴"声'
    })
  },

  loadBatches: function () {
    this.setData({ batches: app.globalData.batches })
  },

  // ===== 设置操作 =====
  toggleDuplicate: function () {
    var s = this.data.settings
    s.allowDuplicate = !s.allowDuplicate
    this.setData({ settings: s })
    app.globalData.settings = s
    app.saveSettings()
  },

  togglePhoto: function () {
    var s = this.data.settings
    s.autoSavePhoto = !s.autoSavePhoto
    this.setData({ settings: s })
    app.globalData.settings = s
    app.saveSettings()
  },

  // ===== 选择器 =====
  openPicker: function (e) {
    var type = e.currentTarget.dataset.type
    var s = this.data.settings
    var title, options, index

    if (type === 'mode') {
      title = '选择扫码模式'
      options = [
        { label: '半屏连扫', value: 'half' },
        { label: '全屏单扫', value: 'full' }
      ]
      index = options.findIndex(function (o) { return o.value === s.scanMode })
    } else if (type === 'scanType') {
      title = '选择扫码类型'
      options = [
        { label: '条形码+二维码', value: 'all' },
        { label: '仅条形码', value: 'barcode' },
        { label: '仅二维码', value: 'qrcode' }
      ]
      index = options.findIndex(function (o) { return o.value === s.scanType })
    } else if (type === 'alert') {
      title = '选择提示方式'
      options = [
        { label: '"滴"声', value: 'sound' },
        { label: '震动', value: 'vibrate' },
        { label: '无提示', value: 'none' }
      ]
      index = options.findIndex(function (o) { return o.value === s.alertType })
    }
    if (index < 0) index = 0

    this.setData({
      showPicker: true,
      pickerTitle: title,
      pickerOptions: options,
      pickerType: type,
      pickerIndex: index
    })
  },

  onPickerChange: function (e) {
    var idx = e.detail.value
    var options = this.data.pickerOptions
    var type = this.data.pickerType
    var selected = options[idx]
    var s = this.data.settings

    if (type === 'mode') s.scanMode = selected.value
    else if (type === 'scanType') s.scanType = selected.value
    else if (type === 'alert') s.alertType = selected.value

    app.globalData.settings = s
    app.saveSettings()
    this.setData({ settings: s })
    this.loadSettings()
  },

  closePicker: function () {
    this.setData({ showPicker: false })
  },

  // ===== 开始扫码：跳转到扫码页面 =====
  startScan: function () {
    wx.navigateTo({ url: '/pages/scanner/scanner' })
  },

  // ===== 管理页操作 =====
  openBatch: function (e) {
    wx.navigateTo({ url: '/pages/detail/detail?id=' + e.currentTarget.dataset.id })
  },

  exportHistory: function () {
    if (this.data.batches.length === 0) {
      wx.showToast({ title: '暂无记录', icon: 'none' })
      return
    }
    var text = ''
    var total = 0
    this.data.batches.forEach(function (batch) {
      text += batch.name + ' (' + batch.time + ')\n'
      batch.items.forEach(function (item) {
        text += '  ' + item.code + ' [' + item.time + ']\n'
        total++
      })
      text += '\n'
    })
    wx.setClipboardData({
      data: text,
      success: function () {
        wx.showToast({ title: '已复制' + total + '条', icon: 'success' })
      }
    })
  },

  clearAll: function () {
    if (this.data.batches.length === 0) {
      wx.showToast({ title: '暂无记录', icon: 'none' })
      return
    }
    var that = this
    wx.showModal({
      title: '确认清除',
      content: '将清除全部' + this.data.batches.length + '个批次，不可恢复',
      confirmColor: '#FF4D4F',
      success: function (res) {
        if (res.confirm) {
          app.clearAllBatches()
          that.loadBatches()
          wx.showToast({ title: '已清除', icon: 'success' })
        }
      }
    })
  }
})
