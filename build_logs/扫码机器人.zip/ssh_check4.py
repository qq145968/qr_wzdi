import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=15)
cmds = [
    'bt 5 2>&1',
    'cat /www/server/panel/data/default.db | strings | grep -A2 -B2 "mysql" | head -20',
    'cd /www/server/panel && python3 -c "import sqlite3; db=sqlite3.connect(\"data/default.db\"); c=db.cursor(); c.execute(\"SELECT name FROM sqlite_master WHERE type=\\\"table\\\"\"); print(c.fetchall())" 2>&1',
    'cd /www/server/panel && python3 -c "import sqlite3; db=sqlite3.connect(\"data/default.db\"); c=db.cursor(); c.execute(\"SELECT mysql_root FROM config LIMIT 1\"); print(c.fetchall())" 2>&1',
    'cat /www/server/nginx/conf/nginx.conf 2>/dev/null | head -60',
    'ls /www/wwwroot/qr.wzdi.cn/ 2>/dev/null',
    'cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf 2>/dev/null',
]
for cmd in cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='replace').strip()
    err = stderr.read().decode('utf-8', errors='replace').strip()
    print(f'CMD: {cmd}')
    if out: print(f'  OUT: {out}')
    if err: print(f'  ERR: {err}')
    print()
ssh.close()
