import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30)

# Test external URL
print('=== Testing external URL ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s https://qr.wzdi.cn/api/app_info.php',
    timeout=15
)
result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'External: {result[:800]}')

# Also check nginx config for /api/
print('\n=== Nginx config ===')
stdin, stdout, stderr = ssh.exec_command(
    'cat /www/server/panel/vhost/nginx/qr.wzdi.cn.conf',
    timeout=10
)
print(stdout.read().decode('utf-8', errors='replace').strip()[:2000])

ssh.close()
