import paramiko
import time
import os

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting to SSH...')
for i in range(3):
    try:
        ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30, banner_timeout=60, auth_timeout=30)
        print(f'Connected on attempt {i+1}!')
        break
    except Exception as e:
        print(f'Attempt {i+1} failed: {e}')
        time.sleep(15)
else:
    print('All SSH attempts failed')
    exit(1)

# Step 1: Upload app_info.php
print('\n=== Uploading app_info.php ===')
sftp = ssh.open_sftp()

local_file = r'e:\工作路径\6a80b60ed76c53d761ba65ee\scan-robot-android\php-api\app_info.php'
remote_file = '/www/wwwroot/qr.wzdi.cn/api/app_info.php'

try:
    sftp.put(local_file, remote_file)
    print(f'Uploaded: app_info.php')
except Exception as e:
    print(f'Failed: {e}')

sftp.close()

# Step 2: Set permissions
print('\n=== Setting permissions ===')
stdin, stdout, stderr = ssh.exec_command(f'chown www:www {remote_file} && chmod 755 {remote_file}', timeout=10)
stdout.read()
print('Permissions set')

# Step 3: Get MySQL root password
print('\n=== Getting MySQL root password ===')
stdin, stdout, stderr = ssh.exec_command(
    'cd /www/server/panel && python3 -c "import sqlite3;db=sqlite3.connect(\'data/default.db\');c=db.cursor();c.execute(\'SELECT mysql_root FROM config\');r=c.fetchone();print(r[0] if r else None)"',
    timeout=15
)
mysql_pwd = stdout.read().decode('utf-8', errors='replace').strip()
err = stderr.read().decode('utf-8', errors='replace').strip()
if err: print(f'Error: {err}')
print(f'MySQL root password: {"found" if mysql_pwd and mysql_pwd != "None" else "not found"}')

# Step 4: Test API first (it will auto-create tables)
print('\n=== Testing app_info.php (auto-creates tables) ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s http://127.0.0.1/api/app_info.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
api_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'API result: {api_result[:500]}')

# Step 5: Insert test data
print('\n=== Inserting test data ===')

# Insert announcement
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "UPDATE app_settings SET setting_value = \'欢迎使用扫码机器人 v1.5.0！新增消息通知、版本更新检测功能。让手机变成扫码枪，高效便捷。\' WHERE setting_key = \'announcement\';" 2>&1',
    timeout=10
)
print(f'Announcement: {stdout.read().decode("utf-8", errors="replace").strip()}')

# Insert a test message
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "INSERT INTO app_messages (title, content, msg_type, target_users, status) VALUES (\'欢迎使用扫码机器人\', \'感谢您使用扫码机器人 v1.5.0！\\n\\n新增功能：\\n1. 消息通知系统\\n2. 版本自动更新检测\\n3. 滚动公告栏\\n\\n如有问题请及时反馈。\', \'system\', \'all\', \'sent\');" 2>&1',
    timeout=10
)
print(f'Message 1: {stdout.read().decode("utf-8", errors="replace").strip()}')

# Insert another message
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "INSERT INTO app_messages (title, content, msg_type, target_users, status) VALUES (\'系统维护通知\', \'系统将于今晚23:00-23:30进行例行维护，届时可能短暂无法访问，请提前做好准备。\', \'system\', \'all\', \'sent\');" 2>&1',
    timeout=10
)
print(f'Message 2: {stdout.read().decode("utf-8", errors="replace").strip()}')

# Insert current version info
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "INSERT INTO app_versions (version_code, version_name, platform, download_url, update_content, force_update, is_published, file_size) VALUES (6, \'1.5.0\', \'all\', \'https://github.com/qq145968/qr_wzdi/releases\', \'v1.5.0 更新内容:\\n1. 修复注册/登录/重置密码闪退问题\\n2. 修复找回密码页面按钮显示不全\\n3. 添加返回键功能支持\\n4. 添加消息通知系统\\n5. 添加滚动公告栏\\n6. 添加版本更新检测\', 0, 1, 0);" 2>&1',
    timeout=10
)
print(f'Version: {stdout.read().decode("utf-8", errors="replace").strip()}')

# Step 6: Verify data
print('\n=== Verifying data ===')
stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "SELECT setting_key, setting_value FROM app_settings;" 2>&1',
    timeout=10
)
print(f'Settings:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "SELECT id, title, msg_type, status FROM app_messages;" 2>&1',
    timeout=10
)
print(f'Messages:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

stdin, stdout, stderr = ssh.exec_command(
    f'mysql -u root -p"{mysql_pwd}" qr_wzdi_cn -e "SELECT version_code, version_name, is_published FROM app_versions;" 2>&1',
    timeout=10
)
print(f'Versions:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

# Step 7: Test API again with data
print('\n=== Testing API with data ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s http://127.0.0.1/api/app_info.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
api_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'API result: {api_result[:800]}')

ssh.close()
print('\n=== Deployment complete! ===')
