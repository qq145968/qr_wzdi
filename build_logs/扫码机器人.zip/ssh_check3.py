import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=15)
cmds = [
    'ls /www/wwwroot/ 2>/dev/null',
    'cat /www/server/panel/data/default.db 2>/dev/null | strings | grep -i password | head -5',
    'cat /www/server/panel/config/config.json 2>/dev/null',
    'bt default 2>/dev/null',
    'cat /www/server/mysql/etc/my.cnf 2>/dev/null | head -20',
    'cat /www/server/panel/data/default_db.json 2>/dev/null',
    'cat /www/server/panel/data/db/default.db 2>/dev/null | strings | head -20',
    'cd /www/server/panel && python3 tools.py get_mysql_root_pwd 2>/dev/null',
    'cat /www/server/panel/data/mysql_root.txt 2>/dev/null',
    'ls /www/server/panel/data/ 2>/dev/null | head -20',
]
for cmd in cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='replace').strip()
    err = stderr.read().decode('utf-8', errors='replace').strip()
    print(f'CMD: {cmd}')
    if out: print(f'  OUT: {out}')
    if err: print(f'  ERR: {err}')
    print()
ssh.close()
