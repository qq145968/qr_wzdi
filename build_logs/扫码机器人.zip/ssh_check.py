import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=15)
cmds = [
    'cat /etc/nginx/nginx.conf | head -50',
    'ls /etc/nginx/conf.d/ 2>/dev/null',
    'cat /etc/nginx/conf.d/*.conf 2>/dev/null | head -80',
    'find /var/www -name "index.php" 2>/dev/null',
    'find /usr/share/nginx -name "index.html" 2>/dev/null',
    'ls -la /usr/share/nginx/html/ 2>/dev/null | head -10',
    'mysql -u root -e "SHOW DATABASES;" 2>&1',
]
for cmd in cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    print(f'CMD: {cmd}')
    if out: print(f'  OUT: {out}')
    if err: print(f'  ERR: {err}')
    print()
ssh.close()
