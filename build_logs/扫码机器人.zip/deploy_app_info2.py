import paramiko
import time

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print('Connecting to SSH...')
for i in range(3):
    try:
        ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=30, banner_timeout=60, auth_timeout=30)
        print(f'Connected on attempt {i+1}!')
        break
    except Exception as e:
        print(f'Attempt {i+1} failed: {e}')
        time.sleep(15)
else:
    print('All SSH attempts failed')
    exit(1)

# Use the database user from config.php
DB_USER = 'qr_wzdi_cn'
DB_PASS = 'nFhKHWxriPK257hh'
DB_NAME = 'qr_wzdi_cn'

# Step 1: Test API with HTTPS (auto-creates tables)
print('\n=== Testing app_info.php via HTTPS (auto-creates tables) ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s -k https://127.0.0.1/api/app_info.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
api_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'API result: {api_result[:500]}')

# Step 2: Insert test data using qr_wzdi_cn database user
print('\n=== Inserting test data ===')

# Insert announcement
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "UPDATE app_settings SET setting_value = \'欢迎使用扫码机器人 v1.5.0！新增消息通知、版本更新检测功能。让手机变成扫码枪，高效便捷。\' WHERE setting_key = \'announcement\';" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Announcement: {result or "OK"}')

# Insert test messages
cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_messages (title, content, msg_type, target_users, status) VALUES ('欢迎使用扫码机器人', '感谢您使用扫码机器人 v1.5.0！\\\\n\\\\n新增功能：\\\\n1. 消息通知系统\\\\n2. 版本自动更新检测\\\\n3. 滚动公告栏\\\\n\\\\n如有问题请及时反馈。', 'system', 'all', 'sent');" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Message 1: {result or "OK"}')

cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_messages (title, content, msg_type, target_users, status) VALUES ('系统维护通知', '系统将于今晚23:00-23:30进行例行维护，届时可能短暂无法访问，请提前做好准备。', 'system', 'all', 'sent');" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Message 2: {result or "OK"}')

# Insert version info
cmd = f"""mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "INSERT INTO app_versions (version_code, version_name, platform, download_url, update_content, force_update, is_published, file_size) VALUES (6, '1.5.0', 'all', 'https://github.com/qq145968/qr_wzdi/releases', 'v1.5.0更新内容：修复闪退、添加消息通知、版本更新检测、滚动公告栏', 0, 1, 0);" 2>&1"""
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'Version: {result or "OK"}')

# Step 3: Verify data
print('\n=== Verifying data ===')
cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT setting_key, LEFT(setting_value,50) as value FROM app_settings;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(f'Settings:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT id, title, msg_type, status FROM app_messages;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(f'Messages:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

cmd = f'mysql -u {DB_USER} -p"{DB_PASS}" {DB_NAME} -e "SELECT version_code, version_name, is_published FROM app_versions;" 2>&1'
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
print(f'Versions:\n{stdout.read().decode("utf-8", errors="replace").strip()}')

# Step 4: Test API with data via HTTPS
print('\n=== Testing API with data ===')
stdin, stdout, stderr = ssh.exec_command(
    'curl -s -k https://127.0.0.1/api/app_info.php -H "Host: qr.wzdi.cn"',
    timeout=15
)
api_result = stdout.read().decode('utf-8', errors='replace').strip()
print(f'API result: {api_result[:1000]}')

ssh.close()
print('\n=== Deployment complete! ===')
