import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('156.225.17.203', port=22, username='root', password='1eZjerlED2NF', timeout=15)
cmds = [
    'nginx -t 2>&1',
    'find / -name "nginx.conf" -type f 2>/dev/null',
    'mysql -u root -p1eZjerlED2NF -e "SHOW DATABASES;" 2>&1',
    'cat /www/server/panel/data/default.db 2>/dev/null | head -1',
    'ls /www/server/ 2>/dev/null',
    'ls /www/wwwroot/ 2>/dev/null',
    'bt 2>/dev/null | head -5',
    'find / -maxdepth 3 -name "nginx.conf" 2>/dev/null',
    'find / -maxdepth 3 -name "my.cnf" 2>/dev/null',
    'cat /etc/my.cnf 2>/dev/null || cat /etc/mysql/my.cnf 2>/dev/null || echo "no my.cnf found"',
]
for cmd in cmds:
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    print(f'CMD: {cmd}')
    if out: print(f'  OUT: {out}')
    if err: print(f'  ERR: {err}')
    print()
ssh.close()
